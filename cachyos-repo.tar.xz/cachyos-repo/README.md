## We are providing a [repositories](https://mirror.cachyos.org/) which includes all kernels in x86-64-v4,x86-64-v3 and x86-64 and more performance-optimized packages
This script add [CachyOS repositories](https://github.com/CachyOS/linux-cachyos#we-are-providing-a-repositories-which-includes-all-kernels-in-x86-64-v4x86-64-v3-and-x86-64-and-more-performance-optimized-packages)
